function m = max(self)
% Returns the maximum z-value
    m = max(self.zdata_lin);
end