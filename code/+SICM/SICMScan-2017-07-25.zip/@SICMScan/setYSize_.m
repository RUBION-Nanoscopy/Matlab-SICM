function setYSize_(self, ysize)
% Helper function: Sets the ysize property
   self.ysize = ysize;
end