function v = volume(self)
% Computes the volume of the data in the scan. Note: The data is taken as
% it is, nothing is subtracted first!
%
% Examples:
%    vol = obj.volume()
% 
%      Computes the volume of the data in `obj`
%      
%  If you want the volume without the z-offset, use:
%
%    obj.subtractMin()
%    vol = obj.volume()

v = self.stepx * self.stepy * sum(self.zdata_lin);