function m = min(self)
% Returns the minimum z-value
    m = min(self.zdata_lin);
end
