function setXSize_(self, xsize)
% Helper function: sets the xsize-property
    self.xsize = xsize;
end