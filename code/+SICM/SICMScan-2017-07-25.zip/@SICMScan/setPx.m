function setPx (self, xpx, ypx)
    % Set the x and y pixels of the object
    self.setPx_(xpx, ypx);
end
