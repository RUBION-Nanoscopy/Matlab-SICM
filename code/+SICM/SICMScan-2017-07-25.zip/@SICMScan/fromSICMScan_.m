function o = fromSICMScan_(obj)
    % Internal function
    % This function copies a SICMScan object.
    
    o = obj.copy();
end