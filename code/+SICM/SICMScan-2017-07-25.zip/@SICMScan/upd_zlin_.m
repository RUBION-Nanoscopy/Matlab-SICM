function upd_zlin_(self)
% Internal function: Shorthand to update zdata_lin from zdata_grid
    self.zdata_lin = self.zdata_grid(:);
end